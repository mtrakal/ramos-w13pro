#!/sbin/sh

/sbin/busybox fdisk /dev/block/avnftli < /etc/fdisk.media.cmd
